import java.util.ArrayList;
public class Banco {
    private ArrayList<ContaBancaria> contas=new ArrayList<>();
    public void adicionarConta(ContaBancaria c){contas.add(c);}
    public ContaBancaria buscarConta(int numero){
        for(ContaBancaria c:contas) if(c.getNumero()==numero) return c;
        return null;
    }
    public void listarContas(){
        System.out.println("\n=== CONTAS CADASTRADAS ===");
        for(ContaBancaria c:contas)
            System.out.println("Conta: "+c.getNumero()+" | Titular: "+c.getTitular());
    }
}
