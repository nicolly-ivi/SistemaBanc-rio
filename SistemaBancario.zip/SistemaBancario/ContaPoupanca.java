public class ContaPoupanca extends ContaBancaria {
    public ContaPoupanca(int numero, String titular){ super(numero,titular);} 
}
