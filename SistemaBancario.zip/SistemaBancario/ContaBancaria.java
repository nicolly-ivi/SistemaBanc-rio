public class ContaBancaria {
    protected int numero;
    protected String titular;
    protected double saldo;

    public ContaBancaria(int numero, String titular) {
        this.numero = numero;
        this.titular = titular;
        this.saldo = 0;
    }

    public void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
            System.out.println("Depósito realizado!");
        }
    }

    public boolean sacar(double valor) {
        if (valor <= saldo) {
            saldo -= valor;
            System.out.println("Saque realizado!");
            return true;
        }
        System.out.println("Saldo insuficiente!");
        return false;
    }

    public void transferir(ContaBancaria destino, double valor) {
        if (sacar(valor)) {
            destino.depositar(valor);
            System.out.println("Transferência realizada!");
        }
    }

    public void consultarSaldo() {
        System.out.println("Saldo: R$ " + saldo);
    }

    public int getNumero() { return numero; }
    public String getTitular() { return titular; }
}
